<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void { Schema::create('services', function(Blueprint $table){ $table->id(); $table->string('name'); $table->string('short_description'); $table->text('description')->nullable(); $table->decimal('price_from',10,2)->nullable(); $table->string('icon')->default('⚙️'); $table->string('status')->default('active'); $table->timestamps(); }); }
 public function down(): void { Schema::dropIfExists('services'); }
};
